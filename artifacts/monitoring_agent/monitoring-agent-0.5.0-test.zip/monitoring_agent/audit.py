from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

from .client import CONTRACT_VERSION
from .settings import RuntimeSettings


AUDIT_CONTRACT_VERSION = 1
TIMING_TOLERANCE_SECONDS = 2.0
TRANSPORT_STATUSES = {
    "connection_error",
    "http_error",
    "schema_error",
    "success",
    "timeout",
}
RETRYABLE_TRANSPORT_STATUSES = {"connection_error", "timeout"}
NON_RETRYABLE_FAILURE_STATUSES = {"http_error", "schema_error"}
OBSERVATION_KEYS = {
    "observation_id",
    "observer_instance_id",
    "endpoint_key",
    "poll_started_at",
    "poll_finished_at",
    "http_status",
    "transport_status",
    "attempt_count",
    "contract_version",
    "source_checked_at",
    "payload",
}
HEARTBEAT_KEYS = {
    "observer_instance_id",
    "recorded_at",
    "process_id",
    "status",
    "cycle_id",
    "cycle_started_at",
    "cycle_finished_at",
    "observation_count",
    "transport_failure_count",
}


class StateAuditError(ValueError):
    """Agent-owned state could not be audited without ambiguity."""


@dataclass(frozen=True)
class _AuditObservation:
    observer_instance_id: str
    endpoint_key: str
    poll_started_at: datetime
    poll_finished_at: datetime
    transport_status: str
    attempt_count: int


@dataclass(frozen=True)
class _CycleSummary:
    started_at: datetime
    finished_at: datetime
    duration_seconds: float
    transport_failure_count: int
    self_health: str
    outcome: str


@dataclass(frozen=True)
class _HeartbeatSummary:
    observer_instance_id: str
    status: str
    cycle_started_at: datetime
    cycle_finished_at: datetime | None
    observation_count: int
    transport_failure_count: int
    process_id_present: bool


def build_state_audit(settings: RuntimeSettings) -> dict[str, object]:
    observations_path = settings.state_dir / "observations.jsonl"
    heartbeat_path = settings.state_dir / "observer_heartbeat.json"
    if not observations_path.is_file():
        raise StateAuditError("observations file is unavailable")

    transport_status_counts: Counter[str] = Counter()
    attempt_count_counts: Counter[int] = Counter()
    self_health_counts: Counter[str] = Counter()
    cycle_outcome_counts: Counter[str] = Counter()
    transition_counts: Counter[str] = Counter()
    instance_ids: set[str] = set()

    total_observation_count = 0
    attempt_over_limit_count = 0
    retryable_not_exhausted_count = 0
    non_retryable_retried_count = 0
    success_after_retry_count = 0
    endpoint_sequence_mismatch_count = 0
    mixed_transport_status_cycle_count = 0
    overlap_count = 0
    early_start_count = 0
    late_beyond_jitter_count = 0
    interval_count = 0
    interval_total = 0.0
    interval_min: float | None = None
    interval_max: float | None = None
    first_degraded_cycle_index: int | None = None
    first_recovery_cycle_index: int | None = None
    complete_cycle_count = 0
    max_attempt_count = 0
    pending_cycle: list[_AuditObservation] = []
    previous_cycle: _CycleSummary | None = None
    last_cycle: _CycleSummary | None = None

    try:
        handle = observations_path.open("r", encoding="utf-8")
    except OSError as exc:
        raise StateAuditError("observations file could not be read") from exc

    with handle:
        for line_number, raw_line in enumerate(handle, start=1):
            if not raw_line.strip():
                raise StateAuditError(
                    f"observation line {line_number} is unexpectedly empty"
                )
            observation = _parse_observation(raw_line, line_number=line_number)
            total_observation_count += 1
            transport_status_counts[observation.transport_status] += 1
            attempt_count_counts[observation.attempt_count] += 1
            instance_ids.add(observation.observer_instance_id)
            max_attempt_count = max(max_attempt_count, observation.attempt_count)

            if observation.attempt_count > settings.max_attempts:
                attempt_over_limit_count += 1
            if (
                observation.transport_status in RETRYABLE_TRANSPORT_STATUSES
                and observation.attempt_count != settings.max_attempts
            ):
                retryable_not_exhausted_count += 1
            if (
                observation.transport_status in NON_RETRYABLE_FAILURE_STATUSES
                and observation.attempt_count != 1
            ):
                non_retryable_retried_count += 1
            if (
                observation.transport_status == "success"
                and observation.attempt_count > 1
            ):
                success_after_retry_count += 1

            pending_cycle.append(observation)
            if len(pending_cycle) < len(settings.endpoint_keys):
                continue

            complete_cycle_count += 1
            actual_endpoint_keys = tuple(item.endpoint_key for item in pending_cycle)
            if actual_endpoint_keys != settings.endpoint_keys:
                endpoint_sequence_mismatch_count += 1

            cycle = _summarize_cycle(pending_cycle)
            self_health_counts[cycle.self_health] += 1
            cycle_outcome_counts[cycle.outcome] += 1
            if len({item.transport_status for item in pending_cycle}) > 1:
                mixed_transport_status_cycle_count += 1

            if first_degraded_cycle_index is None and cycle.self_health == "degraded":
                first_degraded_cycle_index = complete_cycle_count

            if previous_cycle is not None:
                transition = f"{previous_cycle.self_health}_to_{cycle.self_health}"
                transition_counts[transition] += 1
                if (
                    first_recovery_cycle_index is None
                    and previous_cycle.self_health == "degraded"
                    and cycle.self_health == "healthy"
                ):
                    first_recovery_cycle_index = complete_cycle_count

                interval = (cycle.started_at - previous_cycle.started_at).total_seconds()
                interval_count += 1
                interval_total += interval
                interval_min = (
                    interval if interval_min is None else min(interval_min, interval)
                )
                interval_max = (
                    interval if interval_max is None else max(interval_max, interval)
                )
                if cycle.started_at < previous_cycle.finished_at:
                    overlap_count += 1
                expected_minimum = max(
                    settings.poll_interval_seconds,
                    previous_cycle.duration_seconds,
                )
                if interval + TIMING_TOLERANCE_SECONDS < expected_minimum:
                    early_start_count += 1
                if (
                    interval - TIMING_TOLERANCE_SECONDS
                    > expected_minimum + settings.poll_jitter_seconds
                ):
                    late_beyond_jitter_count += 1

            previous_cycle = cycle
            last_cycle = cycle
            pending_cycle = []

    heartbeat = _read_heartbeat(heartbeat_path)
    heartbeat_instance_matches = (
        heartbeat.observer_instance_id in instance_ids if instance_ids else None
    )
    heartbeat_matches_last_cycle: bool | None = None
    if heartbeat.status != "polling" and last_cycle is not None:
        heartbeat_matches_last_cycle = (
            heartbeat.cycle_started_at <= last_cycle.started_at
            and heartbeat.cycle_finished_at is not None
            and heartbeat.cycle_finished_at >= last_cycle.finished_at
            and heartbeat.observation_count == len(settings.endpoint_keys)
            and heartbeat.transport_failure_count
            == last_cycle.transport_failure_count
            and heartbeat.status == last_cycle.self_health
        )

    return {
        "audit_contract_version": AUDIT_CONTRACT_VERSION,
        "event": "agent_state_audit",
        "configuration": {
            "endpoint_count": len(settings.endpoint_keys),
            "max_attempts": settings.max_attempts,
            "poll_interval_seconds": settings.poll_interval_seconds,
            "poll_jitter_seconds": settings.poll_jitter_seconds,
        },
        "observations": {
            "total_count": total_observation_count,
            "complete_cycle_count": complete_cycle_count,
            "trailing_observation_count": len(pending_cycle),
            "observer_instance_count": len(instance_ids),
            "transport_status_counts": dict(sorted(transport_status_counts.items())),
            "attempt_count_counts": {
                str(key): value for key, value in sorted(attempt_count_counts.items())
            },
            "max_attempt_count": max_attempt_count,
            "attempt_over_limit_count": attempt_over_limit_count,
            "retryable_not_exhausted_count": retryable_not_exhausted_count,
            "non_retryable_retried_count": non_retryable_retried_count,
            "success_after_retry_count": success_after_retry_count,
            "attempt_bounds_valid": attempt_over_limit_count == 0,
            "retry_contract_valid": (
                retryable_not_exhausted_count == 0
                and non_retryable_retried_count == 0
            ),
        },
        "cycles": {
            "endpoint_sequence_mismatch_count": endpoint_sequence_mismatch_count,
            "endpoint_sequence_valid": endpoint_sequence_mismatch_count == 0,
            "self_health_counts": dict(sorted(self_health_counts.items())),
            "outcome_counts": dict(sorted(cycle_outcome_counts.items())),
            "mixed_transport_status_count": mixed_transport_status_cycle_count,
            "first_degraded_cycle_index": first_degraded_cycle_index,
            "first_recovery_cycle_index": first_recovery_cycle_index,
            "transition_counts": dict(sorted(transition_counts.items())),
        },
        "timing": {
            "interval_count": interval_count,
            "interval_min_seconds": _rounded(interval_min),
            "interval_max_seconds": _rounded(interval_max),
            "interval_average_seconds": _rounded(
                interval_total / interval_count if interval_count else None
            ),
            "overlap_count": overlap_count,
            "early_start_count": early_start_count,
            "late_beyond_jitter_count": late_beyond_jitter_count,
            "tolerance_seconds": TIMING_TOLERANCE_SECONDS,
        },
        "latest_heartbeat": {
            "status": heartbeat.status,
            "observation_count": heartbeat.observation_count,
            "transport_failure_count": heartbeat.transport_failure_count,
            "process_id_present": heartbeat.process_id_present,
            "observer_instance_matches_observations": heartbeat_instance_matches,
            "matches_last_complete_cycle": heartbeat_matches_last_cycle,
        },
        "evidence_gaps": [
            "heartbeat_transition_history_not_persisted",
            "process_identity_history_not_persisted",
        ],
    }


def _parse_observation(raw_line: str, *, line_number: int) -> _AuditObservation:
    try:
        value = json.loads(raw_line)
    except json.JSONDecodeError as exc:
        raise StateAuditError(
            f"observation line {line_number} contains invalid JSON"
        ) from exc
    if not isinstance(value, dict) or set(value) != OBSERVATION_KEYS:
        raise StateAuditError(f"observation line {line_number} has an invalid schema")
    contract_version = value["contract_version"]
    if (
        isinstance(contract_version, bool)
        or not isinstance(contract_version, int)
        or contract_version != CONTRACT_VERSION
    ):
        raise StateAuditError(
            f"observation line {line_number} has an unsupported contract"
        )
    observation_id = value["observation_id"]
    observer_instance_id = value["observer_instance_id"]
    endpoint_key = value["endpoint_key"]
    transport_status = value["transport_status"]
    attempt_count = value["attempt_count"]
    if not isinstance(observation_id, str) or not observation_id:
        raise StateAuditError(
            f"observation line {line_number} has an invalid observation id"
        )
    if not isinstance(observer_instance_id, str) or not observer_instance_id:
        raise StateAuditError(
            f"observation line {line_number} has an invalid observer instance"
        )
    if not isinstance(endpoint_key, str) or not endpoint_key:
        raise StateAuditError(
            f"observation line {line_number} has an invalid endpoint key"
        )
    if not isinstance(transport_status, str) or (
        transport_status not in TRANSPORT_STATUSES
    ):
        raise StateAuditError(
            f"observation line {line_number} has an invalid transport status"
        )
    if (
        isinstance(attempt_count, bool)
        or not isinstance(attempt_count, int)
        or attempt_count < 1
    ):
        raise StateAuditError(
            f"observation line {line_number} has an invalid attempt count"
        )
    http_status = value["http_status"]
    if http_status is not None and (
        isinstance(http_status, bool) or not isinstance(http_status, int)
    ):
        raise StateAuditError(
            f"observation line {line_number} has an invalid HTTP status"
        )
    source_checked_at = value["source_checked_at"]
    if source_checked_at is not None and not isinstance(source_checked_at, str):
        raise StateAuditError(
            f"observation line {line_number} has an invalid source timestamp"
        )
    if source_checked_at is not None:
        _parse_datetime(
            source_checked_at,
            context=f"observation line {line_number} source timestamp",
        )
    if not isinstance(value["payload"], dict):
        raise StateAuditError(f"observation line {line_number} has an invalid payload")

    started_at = _parse_datetime(
        value["poll_started_at"],
        context=f"observation line {line_number} start",
    )
    finished_at = _parse_datetime(
        value["poll_finished_at"],
        context=f"observation line {line_number} finish",
    )
    if finished_at < started_at:
        raise StateAuditError(
            f"observation line {line_number} finishes before it starts"
        )
    return _AuditObservation(
        observer_instance_id=observer_instance_id,
        endpoint_key=endpoint_key,
        poll_started_at=started_at,
        poll_finished_at=finished_at,
        transport_status=transport_status,
        attempt_count=attempt_count,
    )


def _summarize_cycle(observations: list[_AuditObservation]) -> _CycleSummary:
    started_at = observations[0].poll_started_at
    finished_at = max(item.poll_finished_at for item in observations)
    statuses = {item.transport_status for item in observations}
    transport_failure_count = sum(
        item.transport_status != "success" for item in observations
    )
    self_health = "healthy" if transport_failure_count == 0 else "degraded"
    if transport_failure_count == 0:
        outcome = "healthy"
    elif statuses <= RETRYABLE_TRANSPORT_STATUSES:
        outcome = "unreachable"
    elif "success" in statuses:
        outcome = "partial_failure"
    else:
        outcome = "failed"
    return _CycleSummary(
        started_at=started_at,
        finished_at=finished_at,
        duration_seconds=(finished_at - started_at).total_seconds(),
        transport_failure_count=transport_failure_count,
        self_health=self_health,
        outcome=outcome,
    )


def _read_heartbeat(path: Path) -> _HeartbeatSummary:
    try:
        value: Any = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise StateAuditError("heartbeat file could not be read") from exc
    except json.JSONDecodeError as exc:
        raise StateAuditError("heartbeat file contains invalid JSON") from exc
    if not isinstance(value, dict) or set(value) != HEARTBEAT_KEYS:
        raise StateAuditError("heartbeat file has an invalid schema")
    status = value["status"]
    if not isinstance(status, str) or status not in {
        "polling",
        "healthy",
        "degraded",
    }:
        raise StateAuditError("heartbeat file has an invalid status")
    observer_instance_id = value["observer_instance_id"]
    cycle_id = value["cycle_id"]
    process_id = value["process_id"]
    if not isinstance(observer_instance_id, str) or not observer_instance_id:
        raise StateAuditError("heartbeat file has an invalid observer instance")
    if not isinstance(cycle_id, str) or not cycle_id:
        raise StateAuditError("heartbeat file has an invalid cycle id")
    if isinstance(process_id, bool) or not isinstance(process_id, int) or process_id < 1:
        raise StateAuditError("heartbeat file has an invalid process id")
    observation_count = _non_negative_int(
        value["observation_count"], context="heartbeat observation count"
    )
    transport_failure_count = _non_negative_int(
        value["transport_failure_count"], context="heartbeat transport failure count"
    )
    _parse_datetime(value["recorded_at"], context="heartbeat recorded timestamp")
    cycle_started_at = _parse_datetime(
        value["cycle_started_at"], context="heartbeat cycle start"
    )
    cycle_finished_at = (
        None
        if value["cycle_finished_at"] is None
        else _parse_datetime(
            value["cycle_finished_at"], context="heartbeat cycle finish"
        )
    )
    if transport_failure_count > observation_count:
        raise StateAuditError("heartbeat failure count exceeds observation count")
    if status == "polling" and (
        cycle_finished_at is not None
        or observation_count != 0
        or transport_failure_count != 0
    ):
        raise StateAuditError("polling heartbeat has completed-cycle fields")
    if status != "polling" and cycle_finished_at is None:
        raise StateAuditError("completed heartbeat has no cycle finish")
    if cycle_finished_at is not None and cycle_finished_at < cycle_started_at:
        raise StateAuditError("heartbeat cycle finishes before it starts")
    return _HeartbeatSummary(
        observer_instance_id=observer_instance_id,
        status=status,
        cycle_started_at=cycle_started_at,
        cycle_finished_at=cycle_finished_at,
        observation_count=observation_count,
        transport_failure_count=transport_failure_count,
        process_id_present=True,
    )


def _parse_datetime(value: object, *, context: str) -> datetime:
    if not isinstance(value, str):
        raise StateAuditError(f"{context} is invalid")
    try:
        resolved = datetime.fromisoformat(value)
    except ValueError as exc:
        raise StateAuditError(f"{context} is invalid") from exc
    if resolved.tzinfo is None:
        raise StateAuditError(f"{context} must include a timezone")
    return resolved.astimezone(timezone.utc)


def _non_negative_int(value: object, *, context: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise StateAuditError(f"{context} is invalid")
    return value


def _rounded(value: float | None) -> float | None:
    return None if value is None else round(value, 3)
