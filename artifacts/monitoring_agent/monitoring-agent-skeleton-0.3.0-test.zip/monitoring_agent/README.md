# Monitoring agent test skeleton

This package is the independent read-only observer skeleton for `OPS-002`.
It is not registered as an autonomous or production agent.

Current capabilities:

- loads a strict, versioned, non-secret JSON configuration;
- polls only the compiled-in GET allowlist;
- accepts plain HTTP only for loopback synthetic tests;
- accepts remote targets only through HTTPS;
- bypasses ambient HTTP proxy configuration;
- validates exact synthetic response schemas fail-closed;
- drops non-retained labels and detail text;
- writes normalized observations and its own heartbeat only to the explicitly
  supplied state directory;
- contains no authentication, model, email, manual-job, database, remote
  shell, process-control, or application-write capability in loopback
  synthetic mode;
- requires a separate bearer credential file for every remote HTTPS target
  and never accepts the credential inside JSON configuration.

## Polling and self-health contract

Configuration version 2 defines the test-mode polling behavior explicitly:

- cycles start every 60 seconds plus zero-to-five seconds of random jitter;
- cycles never overlap because one observer process executes them serially;
- each request has a three-second timeout and at most three attempts;
- only connection errors and timeouts are retried, after 0.5 and 1.0 seconds;
- HTTP authorization/status errors, invalid JSON, and schema errors fail
  closed without retry;
- HTTP 503 readiness with the approved `unavailable` payload is retained as
  application evidence, not classified as a transport failure;
- the agent-owned heartbeat is written as `polling` at cycle start and as
  `healthy` or `degraded` at cycle completion;
- target scheduler degradation does not degrade observer self-health when
  transport and schema validation succeed;
- an interrupted cycle leaves the last heartbeat in `polling`, allowing a
  later service-manager or independent self-health rule to detect staleness.

No retry path calls a mutation endpoint, changes the target, or includes a
credential or response body in persisted state.

## Local synthetic test

Terminal 1:

```powershell
.\.venv\Scripts\python.exe -m monitoring_agent.synthetic_server `
    --scenario healthy
```

Terminal 2:

```powershell
Copy-Item monitoring_agent\config.example.json `
    .\monitoring-agent.test.json

.\.venv\Scripts\python.exe -m monitoring_agent `
    --config .\monitoring-agent.test.json `
    --once
```

The example uses a disposable `.local-state` directory beside the copied
configuration. Validate setup without network access or state writes with:

```powershell
.\.venv\Scripts\python.exe -m monitoring_agent `
    --config .\monitoring-agent.test.json `
    --check-config
```

Do not put credentials, tokens, or URLs containing credentials into the
configuration. A future remote foreground invocation uses an ACL-restricted
credential file:

```powershell
python -m monitoring_agent `
    --config .\monitoring-agent.test.json `
    --credential-file C:\ProgramData\monitoring-agent\credentials\facade.token `
    --once
```

The credential file contains only the bearer value. The production-like
Tailscale test will use HTTPS port `9443` only after an explicit Serve and
network-policy approval.

Available synthetic scenarios:

- `healthy`;
- `scheduler_stopped`;
- `readiness_unavailable`;
- `unauthorized`;
- `invalid_schema`.

## Test bundle

Build the reviewed explicit-allowlist ZIP without staging or copying unrelated
repository files:

```powershell
.\.venv-production\Scripts\python.exe `
    scripts\build_monitoring_agent_bundle.py `
    --version 0.3.0-test `
    --created-date 2026-08-04 `
    --output artifacts\monitoring_agent\monitoring-agent-skeleton-0.3.0-test.zip
```

The builder uses fixed ZIP metadata, includes only the ten compiled-in runtime
files, and writes a SHA-256 manifest. It never includes configuration copied
from an operating station, state, reports, logs, credentials, or repository
metadata.

The synthetic server refuses non-loopback binds and implements no control,
log, manual-run, or mutation endpoint.

## Verification

```powershell
.\.venv\Scripts\python.exe -m pytest tests\test_monitoring_agent.py -q
```

Runtime design and security gates remain authoritative in:

- `agents/plans/monitoring/SCHEDULER_MONITORING_AGENT_PLAN.md`;
- `agents/plans/monitoring/SCHEDULER_MONITORING_AGENT_REMOTE_RUNTIME_DESIGN.md`;
- `agents/inventories/MONITORING_AGENT_HEALTH_ENDPOINT_INVENTORY.md`.
