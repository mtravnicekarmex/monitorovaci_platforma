from __future__ import annotations

import argparse
import json
from pathlib import Path
import random
import time

from .client import HealthClient
from .config import AgentConfig
from .credentials import load_bearer_credential
from .observer import run_observation_cycle
from .store import ObserverStore


def calculate_next_cycle_delay(
    *,
    poll_interval_seconds: float,
    cycle_elapsed_seconds: float,
    poll_jitter_seconds: float,
    uniform_fn=random.uniform,
) -> float:
    base_delay = max(0.0, poll_interval_seconds - cycle_elapsed_seconds)
    jitter = uniform_fn(0.0, poll_jitter_seconds)
    return base_delay + jitter


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the read-only monitoring observer in test mode."
    )
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--credential-file",
        type=Path,
        help="ACL-restricted file containing only the monitoring bearer credential.",
    )
    parser.add_argument("--once", action="store_true")
    parser.add_argument(
        "--check-config",
        action="store_true",
        help="Validate configuration and exit without network or state writes.",
    )
    return parser


def main() -> int:
    args = _build_parser().parse_args()
    try:
        config = AgentConfig.load(args.config)
    except ValueError as exc:
        raise SystemExit(f"configuration error: {exc}") from exc

    if args.check_config:
        print(
            json.dumps(
                {
                    "config_version": config.config_version,
                    "endpoint_count": len(config.endpoint_keys),
                    "event": "configuration_valid",
                    "mode": config.mode,
                },
                separators=(",", ":"),
                sort_keys=True,
            )
        )
        return 0

    try:
        bearer_credential = (
            load_bearer_credential(args.credential_file)
            if args.credential_file
            else None
        )
        client = HealthClient(
            base_url=config.base_url,
            observer_instance_id=config.instance_id,
            timeout_seconds=config.timeout_seconds,
            max_attempts=config.max_attempts,
            retry_backoff_seconds=config.retry_backoff_seconds,
            bearer_credential=bearer_credential,
        )
    except ValueError as exc:
        raise SystemExit(f"credential error: {exc}") from exc
    store = ObserverStore(config.state_dir)

    while True:
        cycle_started = time.monotonic()
        observations = run_observation_cycle(
            client=client,
            store=store,
            observer_instance_id=config.instance_id,
            endpoint_keys=config.endpoint_keys,
        )
        print(
            json.dumps(
                {
                    "event": "observation_cycle",
                    "observation_count": len(observations),
                    "transport_statuses": sorted(
                        {item.transport_status for item in observations}
                    ),
                },
                separators=(",", ":"),
                sort_keys=True,
            ),
            flush=True,
        )
        if args.once:
            return 0
        time.sleep(
            calculate_next_cycle_delay(
                poll_interval_seconds=config.poll_interval_seconds,
                cycle_elapsed_seconds=time.monotonic() - cycle_started,
                poll_jitter_seconds=config.poll_jitter_seconds,
            )
        )


if __name__ == "__main__":
    raise SystemExit(main())
